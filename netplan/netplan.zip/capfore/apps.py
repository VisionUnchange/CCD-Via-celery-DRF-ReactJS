from django.apps import AppConfig


class CapforeConfig(AppConfig):
    name = 'capfore'
